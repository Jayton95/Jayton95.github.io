//Page Layering
$('.page').hide();
$('#startPage').show();

$('#controlsButton').click(function() {
	$('.page').hide();
	$('#controlsPage').show();
});

$('#settingsButton').click(function() {
	$('.page').hide();
	$('#settingsPage').show();
});

$('#exitButton').click(function() {
	window.close();
});

//STARTING THE GAME
var draw;

runGame = function() {
	var context;
	var DKey = false;
	var AKey = false;
	var WKey = false;
	var SKey = false;
	var SpaceKey = false;
	var tank1_x;
	var tank1_y;
	var UpKey = false;
	var DownKey = false;
	var RightKey = false;
	var LeftKey = false;
	var SlashKey = false;
	var tank2_x;
	var tank2_y;
	var DEGREE = Math.PI/180;
	var drawTank1;
	var drawTank2;
	var tank1_angle = 3.15;
	var tank2_angle = 0;
	var shells1 = [];
	var shells2 = [];
	var p1Score = 0;
	var p2Score = 0;
	var p1Ammo = 6
	var p2Ammo = 6
	var tank1_ID = 0;
	var tank2_ID = 1;

	function init() {
		context = $('#myCanvas')[0].getContext('2d'); //sets the canvas as a jquery object to the variable 'context'
		WIDTH = $('#myCanvas').width();
		HEIGHT = $('#myCanvas').height();
		tank1_x = WIDTH * 1 / 4; //centre width TANK1
		tank1_y = HEIGHT * 1 / 4; //centre height TANK1
		tank2_x = WIDTH * 3 / 4; //centre width TANK2
		tank2_y = HEIGHT * 3 /4; //centre height TANK2
		setInterval('draw()', 25); //sets interval for draw method to repeat after
	}
	function clearCanvas() {
		context.clearRect(0,0,WIDTH,HEIGHT); // clears whole canvas tank1_ID
	}
	
	drawTank1 = function(x, y, w, h) {
		cos1 = Math.cos(tank1_angle);
		sin1 = Math.sin(tank1_angle);
		var centre_x = tank1_x;
		var centre_y = tank1_y;
		var corner1_x = - 20 * cos1 - 20 * sin1 + centre_x;
		var corner1_y = 20 * sin1 - 20 * cos1 + centre_y;
		var corner2_x = - 20 * cos1 + 20 * sin1 + centre_x;
		var corner2_y = 20 * sin1 + 20 * cos1 + centre_y;
		var corner3_x = 20 * cos1 + 20 * sin1 + centre_x;
		var corner3_y = - 20 * sin1 + 20 * cos1 + centre_y;
		var corner4_x = 20 * cos1 - 20 * sin1 + centre_x;
		var corner4_y = - 20 * sin1 - 20 * cos1 + centre_y;
		var corner5_x = 5 * cos1 - 20 * sin1 + centre_x;
		var corner5_y = - 5 * sin1 - 20 * cos1 + centre_y;
		var corner6_x = 5 * cos1 - 30 * sin1 + centre_x;
		var corner6_y = - 5 * sin1 - 30 * cos1 + centre_y;
		var corner7_x = - 5 * cos1 - 30 * sin1 + centre_x;
		var corner7_y = 5 * sin1 - 30 * cos1 + centre_y;
		var corner8_x = - 5 * cos1 - 20 * sin1 + centre_x;
		var corner8_y = 5 * sin1 - 20 * cos1 + centre_y;
		context.beginPath();
		context.fillStyle = '#00FF00';
		context.moveTo(corner1_x, corner1_y);
		context.lineTo(corner2_x, corner2_y);
		context.lineTo(corner3_x, corner3_y);
		context.lineTo(corner4_x, corner4_y);
		context.lineTo(corner5_x, corner5_y);
		context.lineTo(corner6_x, corner6_y);
		context.lineTo(corner7_x, corner7_y);
		context.lineTo(corner8_x, corner8_y);
		context.lineTo(corner1_x, corner1_y);
		context.closePath();
		context.fill();
		context.stroke();
	}
	
	drawTank2 = function(x, y, w, h) {
		cos1 = Math.cos(tank2_angle);
		sin1 = Math.sin(tank2_angle);
		var centre_x = tank2_x;
		var centre_y = tank2_y;
		var corner1_x = - 20 * cos1 - 20 * sin1 + centre_x;
		var corner1_y = 20 * sin1 - 20 * cos1 + centre_y;
		var corner2_x = - 20 * cos1 + 20 * sin1 + centre_x;
		var corner2_y = 20 * sin1 + 20 * cos1 + centre_y;
		var corner3_x = 20 * cos1 + 20 * sin1 + centre_x;
		var corner3_y = - 20 * sin1 + 20 * cos1 + centre_y;
		var corner4_x = 20 * cos1 - 20 * sin1 + centre_x;
		var corner4_y = - 20 * sin1 - 20 * cos1 + centre_y;
		var corner5_x = 5 * cos1 - 20 * sin1 + centre_x;
		var corner5_y = - 5 * sin1 - 20 * cos1 + centre_y;
		var corner6_x = 5 * cos1 - 30 * sin1 + centre_x;
		var corner6_y = - 5 * sin1 - 30 * cos1 + centre_y;
		var corner7_x = - 5 * cos1 - 30 * sin1 + centre_x;
		var corner7_y = 5 * sin1 - 30 * cos1 + centre_y;
		var corner8_x = - 5 * cos1 - 20 * sin1 + centre_x;
		var corner8_y = 5 * sin1 - 20 * cos1 + centre_y;
		context.beginPath();
		context.fillStyle = '#FF0000';
		context.moveTo(corner1_x, corner1_y);
		context.lineTo(corner2_x, corner2_y);
		context.lineTo(corner3_x, corner3_y);
		context.lineTo(corner4_x, corner4_y);
		context.lineTo(corner5_x, corner5_y);
		context.lineTo(corner6_x, corner6_y);
		context.lineTo(corner7_x, corner7_y);
		context.lineTo(corner8_x, corner8_y);
		context.lineTo(corner1_x, corner1_y);
		context.closePath();
		context.fill();
		context.stroke();
	}
	
	//SHOOTING start
	var fire = function(tank, shells) {
		shell = [tank[0] - 35 * Math.sin(tank[2]), tank[1] - 35 * Math.cos(tank[2]), tank[2]];
		if (shells.length < 6) {
			shells.push(shell);
			recoilAngle = 0.5*Math.random();
			if (tank[3] == 0) {
				p1Ammo--;
				if (recoilAngle < 0.25) {
					tank1_angle -= recoilAngle;
				}
				else {
					recoilAngle = recoilAngle - 0.25;
					tank1_angle += recoilAngle;
				}
			}
			else {
				p2Ammo--;
				if (recoilAngle < 0.25) {
					tank2_angle -= recoilAngle;
				}
				else {
					recoilAngle = recoilAngle - 0.25;
					tank2_angle += recoilAngle;
				}
			}
		}
	}
	//Shooting end
	
	//COLLSION DETECTION start
	collisionDetection = function(tank, shells, opponent, i, centre_x, centre_y) {
		var x_distance = centre_x - opponent[0];
		var y_distance = centre_y - opponent[1];
		var x_selfDistance = centre_x - tank[0];
		var y_selfDistance = centre_y - tank[1];
		var distance = Math.sqrt(x_distance * x_distance + y_distance * y_distance);
		var selfDistance = Math.sqrt(x_selfDistance * x_selfDistance + y_selfDistance * y_selfDistance);
		if (shells[i][0] <= 1 || shells[i][0] >= 1199) {
			shells.splice(i, 1);
			if (tank[4] == 0) {
				p1Ammo++;
			}
			else p2Ammo++;
		}
		if (shells[i][1] <= 1 || shells[i][1] >= 549) {
			shells.splice(i, 1);
			if (tank[4] == 0) {
				p1Ammo++;
			}
			else p2Ammo++;
		}
		if (distance < 25) {
			shells.splice(i, 1);
			if (tank[4] == 0) {
				p1Ammo++;
				p1Score++;
			}
			else {	
				p2Ammo++;
				p2Score++;
			}
			if (p1Score == 5 || p2Score == 5) {
				clearInterval('draw()');
				$('.page').hide();
				$('#gameOverPage').show();
				if (p1Score == 5) {
					$('#score').append("<b>Player 1 Wins!</b>");
				}
				else if (p2Score == 5) {
					$('#score').append("<b>Player 2 Wins!</b>");
				}
			}
		}
	}
	//COLLISION DETECTION end
	
	//SHOOTING AND COLLISION DETECTION CALL start
	drawShells = function(tank, shells, opponent) {
		for (i=0; i<shells.length; i++) {
			cos1 = Math.cos(shells[i][2]);
			sin1 = Math.sin(tank1_angle);
			shells[i][0] -= 10 * Math.sin(shells[i][2]);
			shells[i][1] -= 10 * Math.cos(shells[i][2]);
			var centre_x = shells[i][0];
			var centre_y = shells[i][1];
			var radius = 5;
			context.beginPath();
			context.arc(shells[i][0], shells[i][1], radius, 0, 2 * Math.PI, false);
			context.fillStyle = 'green';
			context.fill();
			context.lineWidth = 0.5;
			collisionDetection(tank, shells, opponent, i, centre_x, centre_y);
		}
		
	}
	//SHOOTING AND COLLISION DETECTION CALL end
	
	//REFRESH GAME OVERLAY start
	refreshGameOverlay = function() {
		$('#gamePageOverlay').empty();
		$('#gamePageOverlay').append('<div id = "p1Stats" class = "stats"></div>');
		$('#gamePageOverlay').append('<div id = "p2Stats" class = "stats"></div>');
		$('#p1Stats').append('<b>PLAYER 1</b><br/>Health: ' + (5-p2Score) + '<br/>Ammo: ' + p1Ammo + '<br/>Score: ' + p1Score + '/5').css("color", "white");
		$('#p2Stats').append('<b>PLAYER 2</b><br/>Health: ' + (5-p1Score) + '<br/>Ammo: ' + p2Ammo + '<br/>Score: ' + p2Score + '/5').css("color", "white");
	}
	//REFRESH GAME OVERLAY end
	
	//DRAW start
	draw = function() {
		//Refresh game page overlay call
		refreshGameOverlay();
		
		clearCanvas();
		//TANK1 ROTATION
		if (DKey) {
			tank1_angle -= 5 * DEGREE;
		}
		else if (AKey) {
			tank1_angle += 5 * DEGREE;
		}
		//TANK1 MOVEMENT
		if (WKey) {
			tank1_x -= 5 * Math.sin(tank1_angle);
			tank1_y -= 5 * Math.cos(tank1_angle);
			if (tank1_x < 0 || tank1_x > 1200 || tank1_y < 0 || tank1_y > 550) {
				tank1_x += 5 * Math.sin(tank1_angle);
				tank1_y += 5 * Math.cos(tank1_angle);
			}
		}
		else if (SKey) {
			tank1_x += 5 * Math.sin(tank1_angle);
			tank1_y += 5 * Math.cos(tank1_angle);
			if (tank1_x < 0 || tank1_x > 1200 || tank1_y < 0 || tank1_y > 550) {
				tank1_x -= 5 * Math.sin(tank1_angle);
				tank1_y -= 5 * Math.cos(tank1_angle);
			}
		}
		drawTank1();
		
		//TANK2 ROTATION
		if (RightKey) {
			tank2_angle -= 5 * DEGREE;
			//drawTank1();
			//drawTank2();
			
		}
		else if (LeftKey) {
			tank2_angle += 5 * DEGREE;
			//drawTank1();
			//drawTank2();
		}
		//TANK2 MOVEMENT
		if (UpKey) {
			tank2_x -= 5 * Math.sin(tank2_angle);
			tank2_y -= 5 * Math.cos(tank2_angle);
			if (tank2_x < 0 || tank2_x > 1200 || tank2_y < 0 || tank2_y > 550) {
				tank2_x += 5 * Math.sin(tank2_angle);
				tank2_y += 5 * Math.cos(tank2_angle);
			}
		}
		else if (DownKey) {
			tank2_x += 5 * Math.sin(tank2_angle);
			tank2_y += 5 * Math.cos(tank2_angle);
			if (tank2_x < 0 || tank2_x > 1200 || tank2_y < 0 || tank2_y > 550) {
				tank2_x -= 5 * Math.sin(tank2_angle);
				tank2_y -= 5 * Math.cos(tank2_angle);
			}
		}
		drawTank2();
		
		//TANK1 FIRING
		if (SpaceKey) {
			fire([tank1_x, tank1_y, tank1_angle, tank1_ID], shells1);
			SpaceKey = false;
		}
		//TANK2 FIRING
		else if (SlashKey) {
			fire([tank2_x, tank2_y, tank2_angle, tank2_ID], shells2);
			SlashKey = false;
		}
		drawShells([tank1_x, tank1_y, tank1_angle, p1Score, tank1_ID], shells1, [tank2_x, tank2_y, tank2_angle]);
		drawShells([tank2_x, tank2_y, tank2_angle, p2Score, tank2_ID], shells2, [tank1_x, tank1_y, tank1_angle]);
	}
	//DRAW end
	
	//Button press detection start
	function onKeyDown(event) {
		//TANK1 (WASD and SPACE Keys)
		if (event.keyCode == 68) DKey = true;
		else if (event.keyCode == 65) AKey = true;
		if (event.keyCode == 87) WKey = true;
		else if (event.keyCode == 83) SKey = true;
		if (event.keyCode == 32) SpaceKey = true;
		//TANK2 (Arrow and '/' Keys)
		if (event.keyCode == 39) RightKey = true;
		else if (event.keyCode == 37) LeftKey = true;
		if (event.keyCode == 38) UpKey = true;
		else if (event.keyCode == 40) DownKey = true;
		if (event.keyCode == 191) SlashKey = true;
	}

	function onKeyUp(event) {
		//TANK1
		if (event.keyCode == 68) DKey = false;
		else if (event.keyCode == 65) AKey = false;
		if (event.keyCode == 87) WKey = false;
		else if (event.keyCode == 83) SKey = false;
		if (event.keyCode == 32) SpaceKey = false;
		else {}
		//TANK2
		if (event.keyCode == 39) RightKey = false;
		else if (event.keyCode == 37) LeftKey = false;
		if (event.keyCode == 38) UpKey = false;
		else if (event.keyCode == 40) DownKey = false;
		if (event.keyCode == 191) SlashKey = false;
		else {}
	}
	//Button press detection end

	$(document).keydown(onKeyDown);
	$(document).keyup(onKeyUp);
	
	init();
}

$('#startButton').click(function() {
	$('.page').hide();
	$('#gamePage').show();
	$('#gamePageOverlay').show();
	runGame();
});


//page layering continued...
$('#controlsBackButton').click(function() {
	$('.page').hide();
	$('#startPage').show();
});

$('#settingsBackButton').click(function() {
	$('.page').hide();
	$('#startPage').show();
});

//Insert game end trigger
//Switches to gameOver Page

$('#restartButton').click(function() {
	location.reload();
});

